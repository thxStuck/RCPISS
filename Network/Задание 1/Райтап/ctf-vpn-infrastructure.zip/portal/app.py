"""
CTF VPN Portal — выдаёт уникальный .ovpn каждому игроку.

Маршруты:
  GET  /            — страница регистрации
  POST /register    — создать/найти игрока, вернуть страницу со ссылкой
  GET  /download/<token>  — скачать .ovpn файл
  GET  /admin       — список игроков (защищён ADMIN_TOKEN из env)
"""

import hashlib
import logging
import os
import secrets
import sqlite3
import subprocess
import textwrap
from pathlib import Path

from flask import Flask, abort, g, redirect, render_template, request, send_file, url_for

# ─── Config ───────────────────────────────────────────────────────────────────

PKI_DIR    = Path(os.environ.get("PKI_DIR",  "/etc/openvpn/pki"))
CCD_DIR    = Path(os.environ.get("CCD_DIR",  "/etc/openvpn/ccd"))
OVPN_DIR   = Path(os.environ.get("OVPN_DIR", "/tmp/configs"))
DB_PATH    = Path(os.environ.get("DB_PATH",  "/data/portal.db"))

VPN_SERVER = os.environ.get("VPN_SERVER_ADDR", "159.194.233.5")
VPN_PORT   = os.environ.get("VPN_PORT",        "1194")

EASYRSA    = Path(os.environ.get("EASYRSA_BIN", "/usr/share/easy-rsa/easyrsa"))
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "changeme")

# IP pool: 10.8.0.10 – 10.8.0.200  (victim=10.8.0.2, server=10.8.0.1, flag=10.8.0.254)
IP_START   = 10
IP_END     = 200

# ─── App ──────────────────────────────────────────────────────────────────────

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s [portal] %(message)s")

OVPN_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# ─── DB helpers ───────────────────────────────────────────────────────────────

def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, check_same_thread=False)
        g.db.row_factory = sqlite3.Row
        g.db.execute("""
            CREATE TABLE IF NOT EXISTS players (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT    UNIQUE NOT NULL,
                ip_octet   INTEGER UNIQUE NOT NULL,
                token      TEXT    UNIQUE NOT NULL,
                created_at TEXT    DEFAULT (datetime('now'))
            )
        """)
        g.db.commit()
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def next_ip_octet(db: sqlite3.Connection) -> int:
    used = {r[0] for r in db.execute("SELECT ip_octet FROM players")}
    for octet in range(IP_START, IP_END + 1):
        # Reserve victim (2) and flagserver (254) just in case
        if octet not in used and octet not in (1, 2, 254):
            return octet
    raise RuntimeError("IP pool exhausted — all octets 10-200 are taken")


# ─── PKI / cert generation ────────────────────────────────────────────────────

def _sanitize(name: str) -> str:
    """Allow only alphanumeric + dash + underscore, max 32 chars."""
    clean = "".join(c for c in name if c.isalnum() or c in "-_")[:32]
    if not clean:
        raise ValueError("Invalid player name")
    return clean


def generate_cert(name: str) -> None:
    """Run EasyRSA to create a client cert/key pair (idempotent)."""
    cert_path = PKI_DIR / "issued" / f"{name}.crt"
    if cert_path.exists():
        logging.info("Cert for %s already exists, skipping.", name)
        return
    env = {
        **os.environ,
        "EASYRSA_PKI":          str(PKI_DIR),
        "EASYRSA_BATCH":        "1",
        "EASYRSA_KEY_SIZE":     "2048",
        "EASYRSA_CERT_EXPIRE":  "3650",
    }
    logging.info("Generating cert for %s …", name)
    subprocess.run(
        [str(EASYRSA), "build-client-full", name, "nopass"],
        env=env, check=True, capture_output=True
    )


def write_ccd(name: str, octet: int) -> None:
    CCD_DIR.mkdir(parents=True, exist_ok=True)
    # tap/bridge mode: second argument is netmask, NOT peer IP (that's tun mode)
    (CCD_DIR / name).write_text(f"ifconfig-push 10.8.0.{octet} 255.255.255.0\n")


def build_ovpn(name: str) -> Path:
    """Assemble an inline .ovpn and cache it in OVPN_DIR."""
    out = OVPN_DIR / f"{name}.ovpn"
    if out.exists():
        return out

    ca   = (PKI_DIR / "ca.crt").read_text()
    cert = subprocess.check_output(
        ["openssl", "x509", "-in", str(PKI_DIR / "issued" / f"{name}.crt")],
        text=True
    )
    key  = (PKI_DIR / "private" / f"{name}.key").read_text()
    ta   = (PKI_DIR / "ta.key").read_text()

    config = textwrap.dedent(f"""
        client
        dev tap
        proto udp
        remote {VPN_SERVER} {VPN_PORT}
        resolv-retry infinite
        nobind
        persist-key
        persist-tun
        cipher AES-256-CBC
        auth SHA256
        tls-version-min 1.2
        verb 3
        key-direction 1

        <ca>
        {ca.strip()}
        </ca>
        <cert>
        {cert.strip()}
        </cert>
        <key>
        {key.strip()}
        </key>
        <tls-auth>
        {ta.strip()}
        </tls-auth>
    """).lstrip()

    out.write_text(config)
    return out


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["POST"])
def register():
    raw_name = request.form.get("name", "").strip()
    try:
        name = _sanitize(raw_name)
    except ValueError:
        return render_template("index.html", error="Имя должно содержать только буквы, цифры, - и _"), 400

    db = get_db()
    row = db.execute("SELECT * FROM players WHERE name = ?", (name,)).fetchone()

    if row is None:
        try:
            octet = next_ip_octet(db)
        except RuntimeError as e:
            return render_template("index.html", error=str(e)), 503

        token = secrets.token_urlsafe(24)
        try:
            generate_cert(name)
            write_ccd(name, octet)
        except subprocess.CalledProcessError as e:
            logging.error("EasyRSA failed: %s", e.stderr)
            return render_template("index.html", error="Ошибка генерации сертификата. Попробуйте позже."), 500

        db.execute(
            "INSERT INTO players (name, ip_octet, token) VALUES (?, ?, ?)",
            (name, octet, token)
        )
        db.commit()
        row = db.execute("SELECT * FROM players WHERE name = ?", (name,)).fetchone()

    download_url = url_for("download_config", token=row["token"], _external=True)
    return render_template(
        "index.html",
        player_name=row["name"],
        player_ip=f"10.8.0.{row['ip_octet']}",
        download_url=download_url,
    )


@app.route("/download/<token>")
def download_config(token: str):
    db = get_db()
    row = db.execute("SELECT * FROM players WHERE token = ?", (token,)).fetchone()
    if row is None:
        abort(404)
    try:
        ovpn_path = build_ovpn(row["name"])
    except Exception as e:
        logging.error("build_ovpn failed: %s", e)
        abort(500)
    return send_file(
        ovpn_path,
        as_attachment=True,
        download_name=f"{row['name']}.ovpn",
        mimetype="application/x-openvpn-profile",
    )


@app.route("/admin")
def admin():
    if request.args.get("token") != ADMIN_TOKEN:
        abort(403)
    db = get_db()
    players = db.execute(
        "SELECT name, ip_octet, created_at FROM players ORDER BY ip_octet"
    ).fetchall()
    return render_template("admin.html", players=players)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
