# Open VPN — Network Traffic Interception

**Category:** Network  
**Difficulty:** Medium  
**Points:** 300

---

## Legend

> Our security team received an alert: somewhere inside the internal corporate VPN segment, an agent is silently transmitting sensitive data to a remote endpoint. The data is sent in plaintext over the internal network.
>
> Your task is to connect to the corporate VPN, observe the traffic in the segment, and intercept the transmitted message.

---

## Description

You are given access to a VPN gateway. Upon connecting, you will be placed in a shared internal network segment alongside other participants and several internal services.

One of the internal hosts is periodically sending a confidential report to another host inside the network. The communication happens in cleartext — no encryption, no obfuscation.

Passive observation of the network traffic is all you need.

**Your goal:** find the flag hidden inside the transmitted message.

---

## Connecting

1. Go to the player portal and register with any nickname:

```
http://159.194.233.5:8080
```

2. Download your personal `.ovpn` configuration file.

3. Connect to the VPN:

```
sudo openvpn --config <your_file>.ovpn
```

4. Once connected, you will receive an IP address in the `10.8.0.0/24` range.

---

## Flag format

```
CTF{...}
```

---

## Notes

- Each participant receives a **unique** VPN certificate — do not share your config with others.
- The flag is transmitted automatically at regular intervals. Be patient.
- No brute force, no exploitation — this challenge is about **listening**, not attacking.
