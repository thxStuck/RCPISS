# Writeup — Open VPN

**Challenge:** Network Traffic Interception  
**Flag:** `CTF{passive_sniff_on_bridge_wins_42}`

---

## Overview

The challenge places participants in a shared VPN L2 segment. An internal "victim" host periodically broadcasts a UDP datagram containing the flag in plaintext. Since the underlying network uses a bridge in hub mode, every VPN client receives every broadcast frame — passive sniffing with `tcpdump` is enough to capture it.

---

## Step-by-step solution

### 1. Register and download your config

Open the player portal in a browser:

```
http://159.194.233.5:8080
```

Enter any nickname and click **Get Config**. A file `<nickname>.ovpn` will be downloaded.

---

### 2. Install OpenVPN (if not already installed)

**Debian / Ubuntu / WSL:**
```bash
sudo apt-get update && sudo apt-get install -y openvpn tcpdump
```

**Arch:**
```bash
sudo pacman -S openvpn tcpdump
```

---

### 3. Connect to the VPN

```bash
sudo openvpn --config ~/Downloads/mynick.ovpn
```

Wait for the line:
```
Initialization Sequence Completed
```

Open a second terminal and verify you got an IP:
```bash
ip addr show tap0
```

Expected output:
```
inet 10.8.0.XX/24 ...
```

---

### 4. Sniff the network traffic

The victim host (`10.8.0.2`) periodically broadcasts a UDP packet to `10.8.0.255:80` containing an HTTP-like payload with the flag.

Run `tcpdump` on the VPN interface:

```bash
sudo tcpdump -i tap0 -A 'udp and dst port 80'
```

After at most 30 seconds you will see output like:

```
12:34:56.789012 IP 10.8.0.2.XXXXX > 10.8.0.255.http: UDP, length 108
E.......@..........
POST /secret HTTP/1.1
Host: 10.8.0.254
Content-Type: application/json
Content-Length: 73

{"from":"internal-reporter","message":"CTF{passive_sniff_on_bridge_wins_42}","host":"victim-bot"}
```

---

### 5. Extract the flag

You can grep it directly:

```bash
sudo tcpdump -i tap0 -A 'udp and dst port 80' 2>/dev/null \
  | grep -o 'CTF{[^}]*}'
```

Output:
```
CTF{passive_sniff_on_bridge_wins_42}
```

---

## One-liner (all steps after VPN is connected)

```bash
sudo tcpdump -i tap0 -A 'udp and dst port 80' 2>/dev/null | grep -o 'CTF{[^}]*}'
```

---

## What is happening under the hood

```
[victim 10.8.0.2] --UDP broadcast--> [br-ctfvpn bridge]
                                            |
                              ageing_time=0 (hub mode)
                              floods ALL frames to ALL ports
                                            |
                                          tap0
                                            |
                                        OpenVPN server
                                       /     |      \
                               player1  player2  player3
                               tap0     tap0     tap0
                               (you)
```

1. The bridge `br-ctfvpn` has `ageing_time 0`, meaning it **never learns MAC addresses** and floods every Ethernet frame to every port.
2. `tap0` (the OpenVPN device) is one of those ports — so it receives every frame.
3. OpenVPN distributes the broadcast frame to **all connected VPN clients**.
4. `tcpdump` on the client's `tap0` captures it in plaintext.

---

## Tools used

| Tool | Purpose |
|------|---------|
| `openvpn` | Connect to the VPN gateway |
| `tcpdump` | Capture network packets |
| (optional) Wireshark | GUI packet analysis |

---

## Difficulty variants

- **Easy:** UDP broadcast — any `tcpdump` on `tap0` captures it immediately.
- **Medium (this challenge):** Same, but participant must know to use `tcpdump` on the VPN interface.
- **Hard variant (not deployed):** Replace broadcast with ARP poisoning + TCP MITM — requires active attack tools.
