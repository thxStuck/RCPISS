#!/usr/bin/env bash
# Entrypoint for the OpenVPN container (network_mode: host).
#
# Architecture:
#   Docker creates bridge "br-ctfvpn" (10.8.0.0/24) for victim/flagserver.
#   This script creates tap0 and attaches it to that Docker bridge.
#   Hub mode (ageing_time=0) makes the bridge flood ALL frames to ALL ports,
#   so VPN clients connected to tap0 see traffic between victim and flagserver.
#
#   br-ctfvpn  10.8.0.0/24
#    ├── veth<victim>     10.8.0.2    Docker container
#    ├── veth<flagserver> 10.8.0.254  Docker container
#    └── tap0             (OpenVPN tap) ← VPN clients connect here

set -euo pipefail
log() { echo "[entrypoint] $*"; }

[ -f /etc/openvpn/pki/ca.crt ] || { log "PKI not found"; exit 1; }

log "Creating tap0"
ip tuntap add dev tap0 mode tap
ip link set tap0 up

log "Joining tap0 to Docker bridge br-ctfvpn"
ip link set tap0 master br-ctfvpn

# Hub mode: ageing_time=0 → bridge never learns MACs → floods ALL frames to ALL ports
# This ensures victim→flagserver UDP broadcasts reach every VPN client
ip link set br-ctfvpn type bridge ageing_time 0
log "Hub mode set: ageing_time=0 on br-ctfvpn"

echo 1 > /proc/sys/net/ipv4/ip_forward || true

log "Starting OpenVPN server (br-ctfvpn + tap0)"
exec openvpn --config /etc/openvpn/server.conf
