#!/usr/bin/env bash
# Convenience wrapper: bulk-generate configs for N players.
#
# Usage:
#   ./gen-all-players.sh <count>
#
# Example (create 10 players: player01..player10):
#   VPN_SERVER_ADDR=ctf.example.com ./gen-all-players.sh 10

set -euo pipefail

COUNT="${1:-5}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[*] Generating $COUNT player configs..."
for i in $(seq 1 "$COUNT"); do
    NAME=$(printf "player%02d" "$i")
    OCTET=$((i + 9))   # player01 → 10.8.0.10, player02 → 10.8.0.11, ...
    echo "--- $NAME (10.8.0.$OCTET) ---"
    VPN_SERVER_ADDR="${VPN_SERVER_ADDR:-127.0.0.1}" \
        "$SCRIPT_DIR/gen-client.sh" "$NAME" "$OCTET"
done

echo ""
echo "[+] Done. Configs are in data/configs/"
ls -1 "$(dirname "$SCRIPT_DIR")/data/configs/"
