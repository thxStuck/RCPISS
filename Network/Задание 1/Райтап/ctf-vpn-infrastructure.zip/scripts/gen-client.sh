#!/usr/bin/env bash
# Generates a per-player OpenVPN client certificate and a ready-to-use .ovpn file.
#
# Usage:
#   ./gen-client.sh <player_name> <player_ip_octet>
#
# Example (assigns 10.8.0.10):
#   ./gen-client.sh player01 10
#
# Requirements:
#   - PKI already initialised via gen-pki.sh
#   - Environment variable VPN_SERVER_ADDR set to the public IP/hostname of the server
#   - Run from a host with EasyRSA and access to ./data/pki

set -euo pipefail

PLAYER="${1:-}"
OCTET="${2:-}"

if [[ -z "$PLAYER" || -z "$OCTET" ]]; then
    echo "Usage: $0 <player_name> <player_ip_last_octet>"
    echo "  e.g. $0 player01 10"
    exit 1
fi

VPN_SERVER_ADDR="${VPN_SERVER_ADDR:-127.0.0.1}"
VPN_PORT="${VPN_PORT:-1194}"
PLAYER_IP="10.8.0.${OCTET}"

EASYRSA_DIR="/usr/share/easy-rsa"
PKI_DIR="$(cd "$(dirname "$0")/../data/pki" && pwd)"
CCD_DIR="$(cd "$(dirname "$0")/../openvpn/ccd" && pwd)"
CONFIGS_DIR="$(cd "$(dirname "$0")/../data/configs" && pwd -P 2>/dev/null || mkdir -p "$(dirname "$0")/../data/configs" && cd "$(dirname "$0")/../data/configs" && pwd)"

export EASYRSA="$EASYRSA_DIR/easyrsa"
export EASYRSA_PKI="$PKI_DIR"
export EASYRSA_BATCH=1
export EASYRSA_KEY_SIZE=2048
export EASYRSA_CERT_EXPIRE=3650

if [ -f "$PKI_DIR/issued/${PLAYER}.crt" ]; then
    echo "[!] Certificate for '$PLAYER' already exists, skipping generation."
else
    echo "[*] Generating certificate for '$PLAYER'"
    "$EASYRSA" build-client-full "$PLAYER" nopass
fi

# ifconfig-push for tap/bridge mode: second arg is netmask (not peer IP like in tun mode)
cat > "$CCD_DIR/$PLAYER" <<EOF
ifconfig-push $PLAYER_IP 255.255.255.0
EOF

# Inline .ovpn assembly
CA_CERT=$(cat "$PKI_DIR/ca.crt")
CLIENT_CERT=$(openssl x509 -in "$PKI_DIR/issued/${PLAYER}.crt")
CLIENT_KEY=$(cat "$PKI_DIR/private/${PLAYER}.key")
TA_KEY=$(cat "$PKI_DIR/ta.key")

OVPN_FILE="$CONFIGS_DIR/${PLAYER}.ovpn"
cat > "$OVPN_FILE" <<EOF
client
dev tap
proto udp
remote $VPN_SERVER_ADDR $VPN_PORT
resolv-retry infinite
nobind
persist-key
persist-tun
cipher AES-256-CBC
verb 3
key-direction 1

<ca>
$CA_CERT
</ca>
<cert>
$CLIENT_CERT
</cert>
<key>
$CLIENT_KEY
</key>
<tls-auth>
$TA_KEY
</tls-auth>
EOF

echo "[+] Config written to: $OVPN_FILE"
echo "    Player IP will be: $PLAYER_IP"
