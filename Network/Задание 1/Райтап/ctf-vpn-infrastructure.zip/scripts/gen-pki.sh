#!/usr/bin/env bash
# Initialises the PKI: CA, DH params, server cert/key, TLS auth key.
# Run once inside the openvpn container or on a Linux host that has EasyRSA.
# Output lands in /etc/openvpn/pki (mapped to ./data/pki on the host).

set -euo pipefail

EASYRSA_DIR="/usr/share/easy-rsa"
PKI_DIR="/etc/openvpn/pki"

if [ ! -d "$EASYRSA_DIR" ]; then
    echo "EasyRSA not found at $EASYRSA_DIR. Install easy-rsa first."
    exit 1
fi

export EASYRSA="$EASYRSA_DIR/easyrsa"
export EASYRSA_PKI="$PKI_DIR"
export EASYRSA_BATCH=1
export EASYRSA_REQ_CN="CTF-CA"
export EASYRSA_KEY_SIZE=2048
export EASYRSA_ALGO=rsa
export EASYRSA_DIGEST=sha256
export EASYRSA_CA_EXPIRE=3650
export EASYRSA_CERT_EXPIRE=3650

echo "[*] Initialising PKI at $PKI_DIR"
"$EASYRSA" init-pki

echo "[*] Building CA (no passphrase)"
"$EASYRSA" build-ca nopass

echo "[*] Generating DH parameters (2048-bit)"
"$EASYRSA" gen-dh

echo "[*] Generating server certificate"
"$EASYRSA" build-server-full server nopass

echo "[*] Generating TLS auth key"
openvpn --genkey secret "$PKI_DIR/ta.key"

echo "[+] PKI initialised successfully."
echo "    CA cert:     $PKI_DIR/ca.crt"
echo "    Server cert: $PKI_DIR/issued/server.crt"
echo "    Server key:  $PKI_DIR/private/server.key"
echo "    DH params:   $PKI_DIR/dh.pem"
echo "    TLS auth:    $PKI_DIR/ta.key"
