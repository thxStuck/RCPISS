#!/usr/bin/env bash
# add-player.sh — add a new CTF player at runtime.
#
# Creates:
#   1. An EasyRSA client certificate
#   2. A CCD file pinning the player to a fixed IP
#   3. An inline .ovpn config ready to hand to the player
#
# Usage (run on the Docker host where ./data/pki and ./openvpn/ccd live):
#   VPN_SERVER_ADDR=1.2.3.4 ./add-player.sh <name> <last_ip_octet>
#
# Example:
#   VPN_SERVER_ADDR=ctf.example.com ./add-player.sh player04 13
#
# IP allocation convention:
#   player01 → 10.8.0.10  (octet 10)
#   player02 → 10.8.0.11  (octet 11)
#   ...
#   player99 → 10.8.0.108 (octet 108)
# Stay within the DHCP pool range: 10.8.0.10 – 10.8.0.200

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

NAME="${1:-}"
OCTET="${2:-}"

if [[ -z "$NAME" || -z "$OCTET" ]]; then
    echo "Usage: $0 <player_name> <last_ip_octet>"
    echo "  e.g. $0 player04 13   → assigns 10.8.0.13"
    exit 1
fi

VPN_SERVER_ADDR="${VPN_SERVER_ADDR:-127.0.0.1}"
VPN_PORT="${VPN_PORT:-1194}"
PLAYER_IP="10.8.0.${OCTET}"
PEER_IP="10.8.0.$((OCTET - 1))"

PKI_DIR="$ROOT_DIR/data/pki"
CCD_DIR="$ROOT_DIR/openvpn/ccd"
CONFIGS_DIR="$ROOT_DIR/data/configs"
EASYRSA_DIR="/usr/share/easy-rsa"

mkdir -p "$CONFIGS_DIR"

# ─── Validate ─────────────────────────────────────────────────────────────────
if [[ ! -f "$PKI_DIR/ca.crt" ]]; then
    echo "[!] PKI not initialised. Run scripts/gen-pki.sh first."
    exit 1
fi

if [[ -f "$CCD_DIR/$NAME" ]]; then
    echo "[!] CCD entry for '$NAME' already exists."
    cat "$CCD_DIR/$NAME"
    echo "[!] Skipping CCD creation."
fi

# ─── Check for IP conflicts ───────────────────────────────────────────────────
CONFLICT=$(grep -rl "$PLAYER_IP" "$CCD_DIR" 2>/dev/null | head -1 || true)
if [[ -n "$CONFLICT" ]]; then
    echo "[!] IP $PLAYER_IP is already assigned in: $CONFLICT"
    exit 1
fi

# ─── Generate certificate ─────────────────────────────────────────────────────
export EASYRSA="$EASYRSA_DIR/easyrsa"
export EASYRSA_PKI="$PKI_DIR"
export EASYRSA_BATCH=1
export EASYRSA_KEY_SIZE=2048
export EASYRSA_CERT_EXPIRE=3650

if [[ -f "$PKI_DIR/issued/${NAME}.crt" ]]; then
    echo "[i] Certificate for '$NAME' already exists, skipping generation."
else
    echo "[*] Generating certificate for $NAME"
    "$EASYRSA" build-client-full "$NAME" nopass
fi

# ─── Write CCD file ───────────────────────────────────────────────────────────
echo "[*] Writing CCD: $NAME → $PLAYER_IP (tap bridge mode: mask 255.255.255.0)"
cat > "$CCD_DIR/$NAME" <<EOF
ifconfig-push $PLAYER_IP 255.255.255.0
EOF

# ─── Assemble .ovpn ───────────────────────────────────────────────────────────
OVPN="$CONFIGS_DIR/${NAME}.ovpn"
echo "[*] Building $OVPN"

CA_CERT=$(cat "$PKI_DIR/ca.crt")
CLIENT_CERT=$(openssl x509 -in "$PKI_DIR/issued/${NAME}.crt")
CLIENT_KEY=$(cat "$PKI_DIR/private/${NAME}.key")
TA_KEY=$(cat "$PKI_DIR/ta.key")

cat > "$OVPN" <<EOF
client
dev tap
proto udp
remote $VPN_SERVER_ADDR $VPN_PORT
resolv-retry infinite
nobind
persist-key
persist-tun
cipher AES-256-CBC
auth SHA256
tls-version-min 1.2
verb 3
key-direction 1

<ca>
$CA_CERT
</ca>
<cert>
$CLIENT_CERT
</cert>
<key>
$CLIENT_KEY
</key>
<tls-auth>
$TA_KEY
</tls-auth>
EOF

echo ""
echo "[+] Player '$NAME' ready."
echo "    Assigned IP : $PLAYER_IP"
echo "    Config file : $OVPN"
echo ""
echo "Hand the player their .ovpn file.  They connect with:"
echo "  sudo openvpn --config ${NAME}.ovpn"
