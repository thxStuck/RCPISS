"""
Victim bot.

Periodically broadcasts a UDP datagram that looks like an HTTP POST request
containing the CTF flag to the subnet broadcast address (10.8.0.255:80).

Because OpenVPN in tap/bridge mode forwards broadcast Ethernet frames to ALL
connected VPN clients, every player sees the packet.  Players capture it with:

    sudo tcpdump -i tap0 -A 'udp and dst port 80'

or the combined one-liner:

    sudo tcpdump -i tap0 -A 'udp and dst port 80' 2>/dev/null | grep -o 'CTF{[^}]*}'
"""

import os
import socket
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [victim] %(message)s",
    datefmt="%H:%M:%S",
)

FLAG       = os.environ.get("CTF_FLAG", "CTF{passive_sniff_on_bridge_wins_42}")
INTERVAL   = int(os.environ.get("SEND_INTERVAL", "30"))
SOURCE_IP  = "10.8.0.2"
BROADCAST  = "10.8.0.255"
TARGET_IP  = "10.8.0.254"
DST_PORT   = 80


def build_payload() -> bytes:
    body = (
        '{"from":"internal-reporter",'
        f'"message":"{FLAG}",'
        '"host":"victim-bot"}'
    )
    return (
        "POST /secret HTTP/1.1\r\n"
        f"Host: {TARGET_IP}\r\n"
        "Content-Type: application/json\r\n"
        f"Content-Length: {len(body)}\r\n"
        "\r\n"
        + body
    ).encode()


# Wait for SOURCE_IP to be assigned before attempting to bind
for _ in range(30):
    try:
        _probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _probe.bind((SOURCE_IP, 0))
        _probe.close()
        break
    except OSError:
        time.sleep(2)

logging.info("Victim bot started. Broadcasting flag every %ds.", INTERVAL)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
try:
    sock.bind((SOURCE_IP, 0))
except OSError:
    sock.bind(("", 0))

while True:
    payload = build_payload()
    sock.sendto(payload, (BROADCAST, DST_PORT))
    logging.info("Broadcast flag -> %s:%d", BROADCAST, DST_PORT)
    time.sleep(INTERVAL)
