# CTF — VPN Sniffing Challenge

Контейнеризованная CTF-задача на перехват трафика в L2-сети.

## Концепция

Игрок подключается к VPN-шлюзу (OpenVPN, tap/bridge режим) и оказывается в
общем Ethernet-сегменте `10.8.0.0/24`.  Мост настроен в **hub-режиме**
(`ageing_time=0`) — все Ethernet-кадры доставляются **всем** клиентам.

В сети крутится `victim-bot` (10.8.0.2), который каждые 30 секунд отправляет
HTTP POST на `flag-server` (10.8.0.254) с флагом в теле запроса.

Задача: перехватить трафик с помощью `tcpdump` или Wireshark и достать флаг.

```
Internet
   │  UDP 1194
   ▼
┌──────────────────────────────┐
│  br0  10.8.0.1/24 (hub)      │
│   ├── tap0 (VPN clients)     │
│   ├── victim-bot  10.8.0.2   │
│   └── flag-server 10.8.0.254 │
└──────────────────────────────┘
        │            │
  10.8.0.10    10.8.0.11  ...
  player01      player02
```

---

## Быстрый старт

### 1. Требования

- Docker + Docker Compose v2
- Linux-хост (нужен `/dev/net/tun` и `cap_add: NET_ADMIN`)
- `easy-rsa` (установится внутри контейнера, но PKI генерируется **снаружи**)

### 2. Инициализация PKI

Первый запуск — на Linux-хосте с установленным `easy-rsa` и `openvpn`:

```bash
# Установить зависимости (Ubuntu/Debian)
sudo apt install easy-rsa openvpn

# Сгенерировать CA, server cert, DH, ta.key
# Результат окажется в ./data/pki/
docker run --rm \
  -v "$(pwd)/data/pki:/etc/openvpn/pki" \
  --entrypoint bash \
  ctf-openvpn -c "/usr/share/easy-rsa/easyrsa init-pki && \
                  /usr/share/easy-rsa/easyrsa build-ca nopass && \
                  /usr/share/easy-rsa/easyrsa gen-dh && \
                  /usr/share/easy-rsa/easyrsa build-server-full server nopass && \
                  openvpn --genkey secret /etc/openvpn/pki/ta.key"
```

Или используйте скрипт (если `easy-rsa` установлен на хосте):

```bash
PKI_DIR="$(pwd)/data/pki" bash scripts/gen-pki.sh
```

### 3. Сгенерировать конфиги для игроков

```bash
# Один игрок
VPN_SERVER_ADDR=<публичный_IP> bash scripts/add-player.sh player01 10

# Сразу N игроков
VPN_SERVER_ADDR=<публичный_IP> bash scripts/gen-all-players.sh 10

# Конфиги окажутся в ./data/configs/*.ovpn
```

### 4. Запустить инфраструктуру

```bash
# Отредактировать .env: установить флаг и адрес сервера
nano .env

docker compose up -d --build
docker compose logs -f
```

### 5. Раздать игрокам .ovpn файлы

Каждый игрок получает свой `playerXX.ovpn`.

---

## Решение задачи (walkthrough)

```bash
# 1. Подключиться к VPN
sudo openvpn --config player01.ovpn

# 2. Убедиться, что получили IP
ip addr show tap0

# 3. Изучить сеть
nmap -sn 10.8.0.0/24
# → 10.8.0.1 (gateway), 10.8.0.2 (victim), 10.8.0.254 (server)

# 4. Перехватить HTTP-трафик
sudo tcpdump -i tap0 -A 'dst 10.8.0.254 and tcp port 80'

# 5. Ждать ~30 секунд, в выводе появится:
#    POST /secret HTTP/1.1
#    {"from": "internal-reporter", "message": "CTF{...}", ...}
```

---

## Варианты усложнения

| Уровень | Описание |
|---------|----------|
| Base (текущий) | Пассивный сниффинг, hub-мост, один флаг |
| Medium | Уникальный флаг на игрока; victim шлёт на IP каждого игрока |
| Hard | Отключить hub-режим (нормальный мост); нужен ARP-спуфинг для перехвата чужого трафика |
| Expert | Флаг разбит по нескольким протоколам (ICMP + UDP + TCP), нужна сборка |

### Уникальные флаги (Medium)

Установить в `.env`:
```
CTF_FLAG=per_player
```
Создать `data/flags/flags.json`:
```json
{
  "10.8.0.10": "CTF{flag_for_player01_aAbBcC}",
  "10.8.0.11": "CTF{flag_for_player02_dDeEfF}"
}
```
`victim.py` читает этот файл и шлёт каждому игроку его уникальный флаг.

---

## Структура проекта

```
.
├── .env                    ← флаг, интервал, адрес сервера
├── docker-compose.yml
├── openvpn/
│   ├── Dockerfile
│   ├── server.conf         ← tap, server-bridge, ccd
│   ├── entrypoint.sh       ← bridge + hub setup
│   └── ccd/                ← player01, player02, ...  (ifconfig-push)
├── victim/
│   ├── Dockerfile
│   └── victim.py
├── flagserver/
│   ├── Dockerfile
│   └── server.py
├── scripts/
│   ├── gen-pki.sh          ← инициализация CA/PKI
│   ├── gen-client.sh       ← один игрок
│   ├── gen-all-players.sh  ← N игроков разом
│   └── add-player.sh       ← добавить игрока в работающую систему
└── data/
    ├── pki/                ← ca.crt, server.crt/key, dh.pem, ta.key
    ├── configs/            ← сгенерированные .ovpn файлы
    └── flags/              ← flags.json (для режима уникальных флагов)
```
