"""
Flag server (10.8.0.254:80).

Accepts POST /secret requests from the victim-bot and logs them.
From the player's perspective this is just a destination that receives
the flag payload in cleartext — the interesting data is in the HTTP body
that travels over the bridged VPN network.

The server does NOT return the flag; it only acknowledges receipt.
Players must sniff the inbound POST, not query this server directly.
"""

import json
import logging
import os
from http.server import BaseHTTPRequestHandler, HTTPServer

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [flagserver] %(message)s",
    datefmt="%H:%M:%S",
)

BIND_HOST = os.environ.get("BIND_HOST", "10.8.0.254")
BIND_PORT = int(os.environ.get("BIND_PORT", "80"))


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        logging.info("%s - %s", self.address_string(), fmt % args)

    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"nothing to see here\n")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else b""
        try:
            data = json.loads(body)
            logging.info("Received payload: %s", json.dumps(data))
        except json.JSONDecodeError:
            logging.info("Received raw body: %r", body)
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"ok\n")


if __name__ == "__main__":
    server = HTTPServer((BIND_HOST, BIND_PORT), Handler)
    logging.info("Flag server listening on %s:%d", BIND_HOST, BIND_PORT)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
